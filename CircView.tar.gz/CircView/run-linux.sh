#!/bin/bash
java -Xms1000m -Xmx2000m -jar CircView.jar